﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHome
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.Panel1 = New System.Windows.Forms.Panel()
		Me.Panel3 = New System.Windows.Forms.Panel()
		Me.txtGenerate = New System.Windows.Forms.TextBox()
		Me.Panel2 = New System.Windows.Forms.Panel()
		Me.btnRun = New System.Windows.Forms.Button()
		Me.lbl1 = New System.Windows.Forms.Label()
		Me.txtInput = New System.Windows.Forms.TextBox()
		Me.Panel1.SuspendLayout()
		Me.Panel3.SuspendLayout()
		Me.Panel2.SuspendLayout()
		Me.SuspendLayout()
		'
		'Panel1
		'
		Me.Panel1.Controls.Add(Me.Panel3)
		Me.Panel1.Controls.Add(Me.Panel2)
		Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
		Me.Panel1.Location = New System.Drawing.Point(0, 0)
		Me.Panel1.Name = "Panel1"
		Me.Panel1.Size = New System.Drawing.Size(911, 429)
		Me.Panel1.TabIndex = 0
		'
		'Panel3
		'
		Me.Panel3.Controls.Add(Me.txtGenerate)
		Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
		Me.Panel3.Location = New System.Drawing.Point(0, 121)
		Me.Panel3.Name = "Panel3"
		Me.Panel3.Size = New System.Drawing.Size(911, 308)
		Me.Panel3.TabIndex = 1
		'
		'txtGenerate
		'
		Me.txtGenerate.Dock = System.Windows.Forms.DockStyle.Fill
		Me.txtGenerate.Location = New System.Drawing.Point(0, 0)
		Me.txtGenerate.Multiline = True
		Me.txtGenerate.Name = "txtGenerate"
		Me.txtGenerate.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.txtGenerate.Size = New System.Drawing.Size(911, 308)
		Me.txtGenerate.TabIndex = 0
		'
		'Panel2
		'
		Me.Panel2.Controls.Add(Me.btnRun)
		Me.Panel2.Controls.Add(Me.lbl1)
		Me.Panel2.Controls.Add(Me.txtInput)
		Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
		Me.Panel2.Location = New System.Drawing.Point(0, 0)
		Me.Panel2.Name = "Panel2"
		Me.Panel2.Size = New System.Drawing.Size(911, 121)
		Me.Panel2.TabIndex = 0
		'
		'btnRun
		'
		Me.btnRun.Location = New System.Drawing.Point(389, 40)
		Me.btnRun.Name = "btnRun"
		Me.btnRun.Size = New System.Drawing.Size(75, 23)
		Me.btnRun.TabIndex = 2
		Me.btnRun.Text = "Run"
		Me.btnRun.UseVisualStyleBackColor = True
		'
		'lbl1
		'
		Me.lbl1.AutoSize = True
		Me.lbl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lbl1.Location = New System.Drawing.Point(12, 18)
		Me.lbl1.Name = "lbl1"
		Me.lbl1.Size = New System.Drawing.Size(98, 20)
		Me.lbl1.TabIndex = 1
		Me.lbl1.Text = "Input deret :"
		'
		'txtInput
		'
		Me.txtInput.Location = New System.Drawing.Point(12, 41)
		Me.txtInput.Name = "txtInput"
		Me.txtInput.Size = New System.Drawing.Size(347, 22)
		Me.txtInput.TabIndex = 0
		'
		'frmHome
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(911, 429)
		Me.Controls.Add(Me.Panel1)
		Me.MaximizeBox = False
		Me.Name = "frmHome"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "Home"
		Me.Panel1.ResumeLayout(False)
		Me.Panel3.ResumeLayout(False)
		Me.Panel3.PerformLayout()
		Me.Panel2.ResumeLayout(False)
		Me.Panel2.PerformLayout()
		Me.ResumeLayout(False)

	End Sub

	Friend WithEvents Panel1 As Panel
	Friend WithEvents Panel3 As Panel
	Friend WithEvents txtGenerate As TextBox
	Friend WithEvents Panel2 As Panel
	Friend WithEvents btnRun As Button
	Friend WithEvents lbl1 As Label
	Friend WithEvents txtInput As TextBox
End Class

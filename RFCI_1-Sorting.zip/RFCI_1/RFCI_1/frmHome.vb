﻿Imports System.Text

Public Class frmHome
	Dim input As String
	Dim dt As New DataTable

	Private Sub btnRun_Click(sender As Object, e As EventArgs) Handles btnRun.Click
		input = CStr(txtInput.Text)
		Dim checkData As Boolean

		If generateToDatatable() > 0 Then
			For i = 0 To dt.Columns.Count - 1
				If dt.Rows(0)(i) = "" Then
					checkData = False
					Exit For
				Else
					checkData = True
				End If
			Next
		End If

		If checkData = True Then
			txtGenerate.Text = generateOutput()
		Else
			txtGenerate.Text = "Error : Perhatikan delimiter (spasi)"
		End If

	End Sub

	Private Sub txtInput_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtInput.KeyPress
		'If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = " " Or e.KeyChar = vbBack) Then e.Handled = True
	End Sub

	Private Function generateToDatatable() As Integer
		dt = New DataTable
		Dim x As Integer = 0
		Dim result As Integer = 0

		Try
			For i = 1 To input.Split(" ").Length
				dt.Columns.Add(i)
			Next

			dt.Rows.Add()

			For Each files As String In input.Split(" ")
				If x <= input.Split(" ").Count - 1 Then
					dt.Rows(0)(x) = files
					x += 1
				End If
			Next

			result = dt.Rows.Count
		Catch ex As Exception
			result = 0
		End Try


		Return result
	End Function

	Private Function generateOutput() As String
		Dim counter As Integer = 0
		Dim nextNum As Integer = 0
		Dim currentColumn As Integer = 0
		Dim nextColumn As Integer = 0
		Dim output As String

		For i As Integer = 0 To dt.Columns.Count - 1

			nextNum = If(i < dt.Columns.Count - 1, i + 1, Nothing) 'column + 1

			If i < dt.Columns.Count - 1 Then
				currentColumn = CInt(dt.Rows(0)(i))
				nextColumn = CInt(dt.Rows(0)(nextNum))

				If currentColumn > nextColumn Then 'Compare
					counter = counter + 1
					dt.Rows(0)(i) = nextColumn
					dt.Rows(0)(nextNum) = currentColumn
					i = -1
					output += ("[" & nextColumn & "," & currentColumn & "] -> ")

					For x As Integer = 0 To dt.Columns.Count - 1
						If x < dt.Columns.Count - 1 Then
							output += ("" & dt.Rows(0)(x) & " ")
						Else
							output += ("" & dt.Rows(0)(x) & " ") & vbCrLf
						End If

					Next

				End If
			End If
		Next

		output += vbCrLf & "Jumlah swap : " & counter

		Return output
	End Function
End Class
